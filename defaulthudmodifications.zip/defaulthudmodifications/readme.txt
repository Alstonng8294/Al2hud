Eniere's Improved default HUD ver. 3.9
March 29, 2018

This is not a custom HUD in its usual meaning, but some fixes for standard Team Fortress 2 UI, adding HP numbers on target IDs, reworked Medic UI, popular custom crosshairs, and more.
Improved default HUD development is complete. No new features are planned — only support for the upcoming major TF2 updates.

Gallery: http://imgur.com/a/l9qai
How-to and changelog: http://eniere.github.io
Donate: http://huds.tf/forum/showthread.php?tid=276

Discussions:
http://teamfortress.tv/thread/16751/improved-default-hud
http://etf2l.org/forum/customise/topic-28385

Reminder: Install all the fonts (idhud-master\resource\fonts\) before use. 
Please, use Notepad++ (http://notepad-plus-plus.org/) to preview or edit files.